<?php
session_start();
header("Access-Control-Allow-Origin: https://scannerst.pro/");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');

// Replace these with your actual database credentials
$servername = 'localhost:3306';
$username = 'scanners_root';
$password = 'Zcjqf6679xk2';
$dbname = 'scanners_stocktaken';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$sessionName = $_SESSION['SessionName'];

// Fetch data from PHPMyAdmin table
$sql = "
SELECT 
    COALESCE(o.barcode, n.barcode) AS barcode,
    COALESCE(o.qty, 0) AS org_qty,
    COALESCE(n.qty, 0) AS new_qty,
    o.qty - COALESCE(n.qty, 0) AS qty_difference,
    CASE 
        WHEN o.barcode IS NOT NULL AND n.barcode IS NOT NULL AND o.qty = n.qty THEN 'Matched'
        ELSE 'Unmatched'
    END AS match_status
FROM $sessionName o
LEFT JOIN (SELECT barcode, sum(qty) as qty from barcodes where qty>0 GROUP by barcode) n ON o.barcode = n.barcode

UNION

SELECT 
    COALESCE(o.barcode, n.barcode) AS barcode,
    COALESCE(o.qty, 0) AS org_qty,
    COALESCE(n.qty, 0) AS new_qty,
    o.qty - COALESCE(n.qty, 0) AS qty_difference,
    CASE 
        WHEN o.barcode IS NOT NULL AND n.barcode IS NOT NULL AND o.qty = n.qty THEN 'Matched'
        ELSE 'Unmatched'
    END AS match_status
FROM $sessionName o
RIGHT JOIN (SELECT barcode, sum(qty) as qty from barcodes where qty>0 GROUP by barcode) n ON o.barcode = n.barcode
WHERE o.barcode IS NULL;

";
$result = mysqli_query($conn, $sql);

// Set headers to force download
header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=Full_Report.csv');
header('Cache-Control: max-age=0');

// Open output stream
$output = fopen('php://output', 'w');

// Output column headers
$columnHeaders = array("Barcode", "Focus Qty", "Physical Qty", "Difference", "Status"); // Replace with your actual column names
fputcsv($output, $columnHeaders);

// Output data
while ($row = mysqli_fetch_assoc($result)) {
    fputcsv($output, $row);
}

// Close output stream
fclose($output);

// Close database connection
mysqli_close($conn);

exit;
?>
